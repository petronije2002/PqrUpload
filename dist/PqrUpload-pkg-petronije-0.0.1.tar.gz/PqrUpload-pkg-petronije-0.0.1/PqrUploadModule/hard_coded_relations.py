topdesk_incident_statuses = {'Nieuw': '243ddef3-9f1c-46d0-96f4-f97fe5f55bbd',
 'In behandeling': '3a43942b-ab8e-4fcf-b57d-e29783eba4d1',
 'Wacht op aanmelder': '6777e95e-f027-5dbc-98c9-11d5abcc14be',
 'Wacht op leverancier': 'ba9a182e-8a1e-513c-bc2e-cdb557fe86df',
 'Gereed': 'c953d77d-f789-432b-8533-68039b7ec831',
 'Afgemeld': '70b2967d-e248-4ff9-a632-ec044410d5a6',
 'Reactie ontvangen': '8228e2f3-1e1f-4563-a970-51487483e7dc',
 'PQR ticketnummer ontvangen': '68cd2dde-1b56-48e9-ac8a-4d068df21c5e',
 'PQR update': '8874e455-c153-4f47-914c-d47994b228aa'}

 '243ddef3-9f1c-46d0-96f4-f97fe5f55bbd','3a43942b-ab8e-4fcf-b57d-e29783eba4d1','6777e95e-f027-5dbc-98c9-11d5abcc14be','ba9a182e-8a1e-513c-bc2e-cdb557fe86df','8228e2f3-1e1f-4563-a970-51487483e7dc'