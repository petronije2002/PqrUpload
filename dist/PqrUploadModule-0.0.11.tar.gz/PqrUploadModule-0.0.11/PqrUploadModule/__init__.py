name = "PqrUploadModule"

import sys
import os


sys.path.append(os.path.abspath("."))
sys.path.append(os.path.abspath("./PqrUploadModule"))

from scanning import Scan

Scan=Scan
# from . import scan


# from . import action_notes_counterparts
# from . import api_functions
# from . import attachment_counterparts
# from . import attachments
# from . import contacts_update
# from . import contacts
# from . import incidents
# from . import notes
# from . import scanning
# from . import authorizations 
# from . import start_settings
# from . import tickets_incidents_counterparts
# from . import tickets


